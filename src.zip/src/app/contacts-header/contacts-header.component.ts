import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'trm-contacts-header',
  templateUrl: './contacts-header.component.html',
  styleUrls: ['./contacts-header.component.css']
})
export class ContactsHeaderComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
