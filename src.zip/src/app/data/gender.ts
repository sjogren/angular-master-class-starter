export const GENDER = [
  'Female',
  'Male',
  'Transgender Female',
  'Transgender Male',
  'Gender Variant / Non-Conforming',
  'Prefer Not to Answer'
];
